// url для запроса к API
const staWarsUrl = "https://swapi.dev/api/films";

// блок с эпизодами
const  episodesDiv = document.getElementById("episodes");

// выполнять выгрузку данных о фильмах при загрузке страницы
window.addEventListener("load", (event) => {
    // выполнение запроса axios
    axios.get(staWarsUrl)
        .then(res => {
            // сценарий если успешно - то для каждой записи создадим блок episode, передав информацию
            for (let episodeInfo of res.data.results) {
                let title = episodeInfo.title;
                let episodeId = episodeInfo.episode_id;
                let releaseYear = new Date(episodeInfo.release_date).getFullYear(); 
                let id = extractIdFromUrl(episodeInfo.url);
                // console.log(id + ": " + title + ", " + episodeId + ", " + releaseYear);
                buildEpisode(id, title, episodeId, releaseYear);
            }
        })
        .catch(err => {
            // сценарий если ошибка
            alert("API ERROR, see browser console");
            console.log(err);
        });
});

function buildEpisode(id, title, episodeId, releaseYear) {
    // создание блока эпизода
    const episodeDiv = document.createElement("div");
    episodeDiv.className = "episode";
    episodeDiv.id = `episode-${id}`;

    // создание блока шапки эпизода
    const episodeHeaderDiv = document.createElement("div");
    episodeHeaderDiv.className = "episode-header";
    episodeHeaderDiv.addEventListener("click", () => fetchEpisodeInfo(id));

    // заполнение информации в шапке
    const titleElement = document.createElement("h2");
    titleElement.className = "episode-title";
    titleElement.textContent = title;
    const infoElement = document.createElement("h3");
    infoElement.className = "episode-info";
    infoElement.textContent = `Episode ${episodeId}, ${releaseYear}`;

    // создание пустого элемента с подробной информацией
    const verboseElement = document.createElement("div");
    verboseElement.className = "episode-verbose";
    verboseElement.id = `episode-verbose-${id}`;
    //verboseElement.textContent = ""; //leave it empty

    // сборка всех элементов в DOM-дереве
    episodeHeaderDiv.appendChild(titleElement);
    episodeHeaderDiv.appendChild(infoElement);
    episodeDiv.appendChild(episodeHeaderDiv);
    episodeDiv.appendChild(verboseElement);

    // добавление в контейнер
     episodesDiv.appendChild(episodeDiv);
}

// fetchEpisodeInfo - получение подроной информации о конкретном эпизоде
function fetchEpisodeInfo(id) {
    clearAllVerboseContent(id);   // очистить подробную информацию в других эпизодах
    // сделать запрос на данный эпизод
    axios.get(`${staWarsUrl}/${id}`)
        .then(res => {
            let verbose = res.data.opening_crawl.replaceAll("\r\n", " ");
            document.getElementById(`episode-verbose-${id}`).textContent = verbose;
        })
        .catch(err => {
            // сценарий если ошибка
            alert("API ERROR, see browser console");
            console.log(err);
        });
}

function clearAllVerboseContent(id) {
    const verboseElements = document.querySelectorAll(".episode-verbose");
    for (const element of verboseElements) {
        if (element.id != `episode-verbose-${id}`) {
            element.textContent = "";
        }
    }
}

function extractIdFromUrl(url) {
    if (typeof url !== 'string') {
      return null;
    }
    const match = url.match(/\/(\d+)\/$/);
    if (match) {
      return parseInt(match[1], 10);
    }
    return null;
}